package bit701.day0830;

public class OperEx6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//산술 연산자
		int su1=7, su2=4;
		System.out.println(su1+su2);//1
		System.out.println(su1-su2);//3
		System.out.println(su1*su2);//28
		System.out.println(su1/su2);//1
		System.out.println((double)su1/su2);//1.75
		System.out.println(su1%su2);//3 :나머지	
	}
}
