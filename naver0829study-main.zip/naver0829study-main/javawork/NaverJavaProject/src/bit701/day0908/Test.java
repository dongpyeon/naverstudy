package bit701.day0908;

public class Test {
	//인스턴스 멤버 변수
	public String str1="Hello World!";
	protected String str2="야호. 금요일이다!";
	String str3="클래스를 공부합시다!";
	private String str4="나만 볼거야!";
	
}
