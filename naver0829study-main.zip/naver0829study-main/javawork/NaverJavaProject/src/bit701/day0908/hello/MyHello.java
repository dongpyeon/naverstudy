package bit701.day0908.hello;

//다른 패키지에서 생성할경우 접근지정자는 public 이라야 한다
public class MyHello {
	public void hello()
	{
		System.out.println("다른 패키지의 hello 메서드");
	}
}
